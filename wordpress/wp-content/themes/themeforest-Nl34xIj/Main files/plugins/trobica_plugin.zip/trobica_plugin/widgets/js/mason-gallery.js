(function($) {
    "use strict";


	$('.mason-gallery').imagesLoaded(function() {$('.mason-gallery').isotope();});


})(jQuery);